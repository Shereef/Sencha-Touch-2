module Gem
  @sources = ["http://gems.rubyforge.org"]
  def self.sources
    @sources
  end
end
