# For --require testing

TESTING_REQUIRE << 1
